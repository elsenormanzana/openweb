--
-- PostgreSQL database dump
--

\restrict aByHmUSp6eH7jzXj5afKtI6hu5yNeh06d3gmR93ntnRBADZ3ZfdqKx8ABYVXbCd

-- Dumped from database version 18.2 (Debian 18.2-1.pgdg13+1)
-- Dumped by pg_dump version 18.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.theme_packs DROP CONSTRAINT IF EXISTS theme_packs_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.storage_config DROP CONSTRAINT IF EXISTS storage_config_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_subscribers DROP CONSTRAINT IF EXISTS newsletter_subscribers_site_id_sites_id_fk;
ALTER TABLE IF EXISTS ONLY public.forms DROP CONSTRAINT IF EXISTS forms_site_id_sites_id_fk;
ALTER TABLE IF EXISTS ONLY public.crm_leads DROP CONSTRAINT IF EXISTS crm_leads_site_id_sites_id_fk;
ALTER TABLE IF EXISTS ONLY public.crm_leads DROP CONSTRAINT IF EXISTS crm_leads_form_id_forms_id_fk;
ALTER TABLE IF EXISTS ONLY public.crm_leads DROP CONSTRAINT IF EXISTS crm_leads_channel_id_crm_channels_id_fk;
ALTER TABLE IF EXISTS ONLY public.crm_channels DROP CONSTRAINT IF EXISTS crm_channels_site_id_sites_id_fk;
ALTER TABLE IF EXISTS ONLY public.blog_tags DROP CONSTRAINT IF EXISTS blog_tags_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_posts DROP CONSTRAINT IF EXISTS blog_posts_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_posts DROP CONSTRAINT IF EXISTS blog_posts_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_posts DROP CONSTRAINT IF EXISTS blog_posts_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_tags DROP CONSTRAINT IF EXISTS blog_post_tags_tag_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_tags DROP CONSTRAINT IF EXISTS blog_post_tags_post_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_categories DROP CONSTRAINT IF EXISTS blog_post_categories_post_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_categories DROP CONSTRAINT IF EXISTS blog_post_categories_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_authors DROP CONSTRAINT IF EXISTS blog_post_authors_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_authors DROP CONSTRAINT IF EXISTS blog_post_authors_post_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blog_categories DROP CONSTRAINT IF EXISTS blog_categories_site_id_fkey;
DROP INDEX IF EXISTS public.users_auth_provider_provider_id_unique;
DROP INDEX IF EXISTS public.blog_tags_site_slug_unique;
DROP INDEX IF EXISTS public.blog_posts_site_slug_unique;
DROP INDEX IF EXISTS public.blog_post_tags_post_tag_unique;
DROP INDEX IF EXISTS public.blog_post_categories_post_category_unique;
DROP INDEX IF EXISTS public.blog_post_authors_post_user_unique;
DROP INDEX IF EXISTS public.blog_categories_site_slug_unique;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_unique;
ALTER TABLE IF EXISTS ONLY public.theme_packs DROP CONSTRAINT IF EXISTS theme_packs_slug_unique;
ALTER TABLE IF EXISTS ONLY public.theme_packs DROP CONSTRAINT IF EXISTS theme_packs_pkey;
ALTER TABLE IF EXISTS ONLY public.storage_config DROP CONSTRAINT IF EXISTS storage_config_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_slug_unique;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.site_settings DROP CONSTRAINT IF EXISTS site_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.plugins DROP CONSTRAINT IF EXISTS plugins_slug_unique;
ALTER TABLE IF EXISTS ONLY public.plugins DROP CONSTRAINT IF EXISTS plugins_pkey;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_site_slug_unique;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_subscribers DROP CONSTRAINT IF EXISTS newsletter_subscribers_site_email_unique;
ALTER TABLE IF EXISTS ONLY public.newsletter_subscribers DROP CONSTRAINT IF EXISTS newsletter_subscribers_pkey;
ALTER TABLE IF EXISTS ONLY public.media_items DROP CONSTRAINT IF EXISTS media_items_pkey;
ALTER TABLE IF EXISTS ONLY public.forms DROP CONSTRAINT IF EXISTS forms_site_slug_unique;
ALTER TABLE IF EXISTS ONLY public.forms DROP CONSTRAINT IF EXISTS forms_pkey;
ALTER TABLE IF EXISTS ONLY public.crm_leads DROP CONSTRAINT IF EXISTS crm_leads_pkey;
ALTER TABLE IF EXISTS ONLY public.crm_channels DROP CONSTRAINT IF EXISTS crm_channels_site_slug_unique;
ALTER TABLE IF EXISTS ONLY public.crm_channels DROP CONSTRAINT IF EXISTS crm_channels_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_tags DROP CONSTRAINT IF EXISTS blog_tags_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_posts DROP CONSTRAINT IF EXISTS blog_posts_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_tags DROP CONSTRAINT IF EXISTS blog_post_tags_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_categories DROP CONSTRAINT IF EXISTS blog_post_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_post_authors DROP CONSTRAINT IF EXISTS blog_post_authors_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_categories DROP CONSTRAINT IF EXISTS blog_categories_pkey;
ALTER TABLE IF EXISTS ONLY drizzle.__drizzle_migrations DROP CONSTRAINT IF EXISTS __drizzle_migrations_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.theme_packs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.storage_config ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.site_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.plugins ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.newsletter_subscribers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.media_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.forms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.crm_leads ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.crm_channels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_post_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_post_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_post_authors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS drizzle.__drizzle_migrations ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.theme_packs_id_seq;
DROP TABLE IF EXISTS public.theme_packs;
DROP SEQUENCE IF EXISTS public.storage_config_id_seq;
DROP TABLE IF EXISTS public.storage_config;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP SEQUENCE IF EXISTS public.site_settings_id_seq;
DROP TABLE IF EXISTS public.site_settings;
DROP SEQUENCE IF EXISTS public.plugins_id_seq;
DROP TABLE IF EXISTS public.plugins;
DROP SEQUENCE IF EXISTS public.pages_id_seq;
DROP TABLE IF EXISTS public.pages;
DROP SEQUENCE IF EXISTS public.newsletter_subscribers_id_seq;
DROP TABLE IF EXISTS public.newsletter_subscribers;
DROP SEQUENCE IF EXISTS public.media_items_id_seq;
DROP TABLE IF EXISTS public.media_items;
DROP SEQUENCE IF EXISTS public.forms_id_seq;
DROP TABLE IF EXISTS public.forms;
DROP SEQUENCE IF EXISTS public.crm_leads_id_seq;
DROP TABLE IF EXISTS public.crm_leads;
DROP SEQUENCE IF EXISTS public.crm_channels_id_seq;
DROP TABLE IF EXISTS public.crm_channels;
DROP SEQUENCE IF EXISTS public.blog_tags_id_seq;
DROP TABLE IF EXISTS public.blog_tags;
DROP SEQUENCE IF EXISTS public.blog_posts_id_seq;
DROP TABLE IF EXISTS public.blog_posts;
DROP SEQUENCE IF EXISTS public.blog_post_tags_id_seq;
DROP TABLE IF EXISTS public.blog_post_tags;
DROP SEQUENCE IF EXISTS public.blog_post_categories_id_seq;
DROP TABLE IF EXISTS public.blog_post_categories;
DROP SEQUENCE IF EXISTS public.blog_post_authors_id_seq;
DROP TABLE IF EXISTS public.blog_post_authors;
DROP SEQUENCE IF EXISTS public.blog_categories_id_seq;
DROP TABLE IF EXISTS public.blog_categories;
DROP SEQUENCE IF EXISTS drizzle.__drizzle_migrations_id_seq;
DROP TABLE IF EXISTS drizzle.__drizzle_migrations;
DROP SCHEMA IF EXISTS drizzle;
--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: blog_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_categories (
    id integer NOT NULL,
    site_id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: blog_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blog_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blog_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blog_categories_id_seq OWNED BY public.blog_categories.id;


--
-- Name: blog_post_authors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_post_authors (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: blog_post_authors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blog_post_authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blog_post_authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blog_post_authors_id_seq OWNED BY public.blog_post_authors.id;


--
-- Name: blog_post_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_post_categories (
    id integer NOT NULL,
    post_id integer NOT NULL,
    category_id integer NOT NULL
);


--
-- Name: blog_post_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blog_post_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blog_post_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blog_post_categories_id_seq OWNED BY public.blog_post_categories.id;


--
-- Name: blog_post_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_post_tags (
    id integer NOT NULL,
    post_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: blog_post_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blog_post_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blog_post_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blog_post_tags_id_seq OWNED BY public.blog_post_tags.id;


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_posts (
    id integer NOT NULL,
    site_id integer NOT NULL,
    title text NOT NULL,
    description text,
    content text,
    slug text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    date_published timestamp without time zone,
    header_image text,
    approval_notes text,
    created_by integer,
    updated_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blog_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blog_posts_id_seq OWNED BY public.blog_posts.id;


--
-- Name: blog_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_tags (
    id integer NOT NULL,
    site_id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: blog_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blog_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blog_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blog_tags_id_seq OWNED BY public.blog_tags.id;


--
-- Name: crm_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_channels (
    id integer NOT NULL,
    site_id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: crm_channels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.crm_channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: crm_channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.crm_channels_id_seq OWNED BY public.crm_channels.id;


--
-- Name: crm_leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_leads (
    id integer NOT NULL,
    site_id integer NOT NULL,
    form_id integer,
    channel_id integer,
    source text DEFAULT 'custom'::text NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    name text,
    email text,
    phone text,
    company text,
    notes text,
    payload text DEFAULT '{}'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: crm_leads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.crm_leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: crm_leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.crm_leads_id_seq OWNED BY public.crm_leads.id;


--
-- Name: forms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forms (
    id integer NOT NULL,
    site_id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    submit_label text DEFAULT 'Submit'::text NOT NULL,
    success_message text DEFAULT 'Thanks, we received your submission.'::text NOT NULL,
    fields text DEFAULT '[]'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: forms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.forms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: forms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.forms_id_seq OWNED BY public.forms.id;


--
-- Name: media_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media_items (
    id integer NOT NULL,
    site_id integer NOT NULL,
    filename text NOT NULL,
    mime_type text NOT NULL,
    size text,
    url text NOT NULL,
    provider text DEFAULT 'local'::text NOT NULL,
    provider_path text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: media_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.media_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.media_items_id_seq OWNED BY public.media_items.id;


--
-- Name: newsletter_subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.newsletter_subscribers (
    id integer NOT NULL,
    site_id integer NOT NULL,
    email text NOT NULL,
    name text,
    status text DEFAULT 'subscribed'::text NOT NULL,
    source text DEFAULT 'newsletter'::text NOT NULL,
    meta text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: newsletter_subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.newsletter_subscribers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: newsletter_subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.newsletter_subscribers_id_seq OWNED BY public.newsletter_subscribers.id;


--
-- Name: pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages (
    id integer NOT NULL,
    site_id integer NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text,
    is_homepage boolean DEFAULT false NOT NULL,
    ignore_global_layout boolean DEFAULT false NOT NULL,
    seo_title text,
    seo_description text,
    seo_keywords text,
    og_image text,
    no_index boolean DEFAULT false NOT NULL,
    canonical_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    disable_elevated_nav_spacing boolean DEFAULT false NOT NULL
);


--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugins (
    id integer NOT NULL,
    site_id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    server_code text,
    client_code text,
    enabled boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: plugins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plugins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plugins_id_seq OWNED BY public.plugins.id;


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id integer NOT NULL,
    site_id integer NOT NULL,
    nav_type text DEFAULT 'navbar'::text NOT NULL,
    nav_config text,
    footer_config text,
    seo_config text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    blog_approval_mode boolean DEFAULT false NOT NULL
);


--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    domain text,
    sub_domain text,
    routing_mode text DEFAULT 'url'::text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: storage_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_config (
    id integer NOT NULL,
    provider text DEFAULT 'local'::text NOT NULL,
    config text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: storage_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.storage_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: storage_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.storage_config_id_seq OWNED BY public.storage_config.id;


--
-- Name: theme_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.theme_packs (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    css_content text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: theme_packs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.theme_packs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: theme_packs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.theme_packs_id_seq OWNED BY public.theme_packs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'subscriber'::text NOT NULL,
    site_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    site_roles text,
    bio text,
    avatar_url text,
    social_media text,
    "position" text,
    auth_provider text,
    auth_provider_id text
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Name: blog_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_categories ALTER COLUMN id SET DEFAULT nextval('public.blog_categories_id_seq'::regclass);


--
-- Name: blog_post_authors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_authors ALTER COLUMN id SET DEFAULT nextval('public.blog_post_authors_id_seq'::regclass);


--
-- Name: blog_post_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_categories ALTER COLUMN id SET DEFAULT nextval('public.blog_post_categories_id_seq'::regclass);


--
-- Name: blog_post_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_tags ALTER COLUMN id SET DEFAULT nextval('public.blog_post_tags_id_seq'::regclass);


--
-- Name: blog_posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_id_seq'::regclass);


--
-- Name: blog_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_tags ALTER COLUMN id SET DEFAULT nextval('public.blog_tags_id_seq'::regclass);


--
-- Name: crm_channels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_channels ALTER COLUMN id SET DEFAULT nextval('public.crm_channels_id_seq'::regclass);


--
-- Name: crm_leads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_leads ALTER COLUMN id SET DEFAULT nextval('public.crm_leads_id_seq'::regclass);


--
-- Name: forms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forms ALTER COLUMN id SET DEFAULT nextval('public.forms_id_seq'::regclass);


--
-- Name: media_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_items ALTER COLUMN id SET DEFAULT nextval('public.media_items_id_seq'::regclass);


--
-- Name: newsletter_subscribers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_subscribers ALTER COLUMN id SET DEFAULT nextval('public.newsletter_subscribers_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: plugins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins ALTER COLUMN id SET DEFAULT nextval('public.plugins_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: storage_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_config ALTER COLUMN id SET DEFAULT nextval('public.storage_config_id_seq'::regclass);


--
-- Name: theme_packs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.theme_packs ALTER COLUMN id SET DEFAULT nextval('public.theme_packs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	70eadf774ef2b141bbcfb3fe5a0146cfd5ff3048c927886d51830cdc4a38ff12	1772056805064
2	2c03cbb3e6fc47cb17818f2bae55bc8bf7eb101df2cc2accb70b6f5beb290dfb	1772056900000
3	edc5cf4b9b3e1af1a9ac3ad77ba8316da0d4d613a562c4c9d9434a770fc526d4	1772057000000
4	9147a3f9f2927e1aec2dc7b667dcfa00b5bb7ac716af822151e63cb6ad3aff36	1772064235213
5	610060af98d2e1326b52a772e6304833415e4064d2e119ef8f894a46363b8c7e	1772150400000
6	60876cb212f5191b617c6c5b639fd168ad5651ab83133cd2c6d4e5fb92217ba6	1772200000000
7	58b9ce4584c36eab24842003ac70433d75579b3d1e809c8e90d20c6dd9397fac	1772226000000
8	54da739b47663667789ee7d67ee7c6a122190a5683f250caaf49c6fad3c2b2af	1772230000000
9	7ad0c5b4d234ca73c118cea167b812893fd0c89367f32370dcf2399b1c61d11e	1772235000000
\.


--
-- Data for Name: blog_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_categories (id, site_id, name, slug, created_at) FROM stdin;
\.


--
-- Data for Name: blog_post_authors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_post_authors (id, post_id, user_id) FROM stdin;
\.


--
-- Data for Name: blog_post_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_post_categories (id, post_id, category_id) FROM stdin;
\.


--
-- Data for Name: blog_post_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_post_tags (id, post_id, tag_id) FROM stdin;
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_posts (id, site_id, title, description, content, slug, status, date_published, header_image, approval_notes, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: blog_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_tags (id, site_id, name, slug, created_at) FROM stdin;
\.


--
-- Data for Name: crm_channels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crm_channels (id, site_id, name, slug, description, is_active, created_at, updated_at) FROM stdin;
1	1	Newsletter	newsletter	newsletter channel	t	2026-02-26 23:38:45.883414	2026-02-26 23:38:45.884
\.


--
-- Data for Name: crm_leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crm_leads (id, site_id, form_id, channel_id, source, status, name, email, phone, company, notes, payload, created_at, updated_at) FROM stdin;
1	1	\N	1	newsletter	new	Carlos Diaz	manzana.carlosdiaz@gmail.com	\N	\N	\N	{"source":"newsletter_block","meta":{},"userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36","ip":"127.0.0.1"}	2026-02-26 23:38:45.877	2026-02-26 23:38:45.877
\.


--
-- Data for Name: forms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forms (id, site_id, name, slug, description, status, submit_label, success_message, fields, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: media_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media_items (id, site_id, filename, mime_type, size, url, provider, provider_path, created_at) FROM stdin;
1	3	aperfi-logo.jpg	image/jpeg	16214	/uploads/ae86b768-9168-413a-a9d6-1580eb717e7e.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/ae86b768-9168-413a-a9d6-1580eb717e7e.jpg	2026-02-26 20:50:27.624565
3	4	colegio-aerea-scaled.jpg	image/jpeg	804972	/uploads/4ad68946-c2c8-477a-84af-cef15b042f86.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/4ad68946-c2c8-477a-84af-cef15b042f86.jpg	2026-02-26 21:45:36.297239
4	4	aperfi-logo.jpg	image/jpeg	16214	/uploads/c3b7a0ee-dcbe-4f77-95c9-0801fef2e39a.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/c3b7a0ee-dcbe-4f77-95c9-0801fef2e39a.jpg	2026-02-26 21:45:43.387236
5	4	carlosdiaz.jpg	image/jpeg	68786	/uploads/67d2626c-a4e9-4fb4-8e0f-a8173be4304e.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/67d2626c-a4e9-4fb4-8e0f-a8173be4304e.jpg	2026-02-26 21:45:49.277313
6	4	b7kfkpqsbeqmm1e2edn.jpg	image/jpeg	29458	/uploads/e9d6eca0-6d03-42e0-b2a0-e0db0bdfc5c8.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/e9d6eca0-6d03-42e0-b2a0-e0db0bdfc5c8.jpg	2026-02-26 21:45:53.821719
7	4	kof7wlowmckmm1e0qvz.jpg	image/jpeg	32903	/uploads/ec872936-e48a-496b-bac6-019f1226ac51.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/ec872936-e48a-496b-bac6-019f1226ac51.jpg	2026-02-26 21:46:02.150053
8	4	qjbdk3rwsqmm1dz5mj.jpg	image/jpeg	32601	/uploads/015f0cea-001f-4207-8829-18d3313a4781.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/015f0cea-001f-4207-8829-18d3313a4781.jpg	2026-02-26 21:46:06.888528
13	1	colegio-aerea-scaled.jpg	image/jpeg	804972	/uploads/877d92a3-2117-4530-aa3d-e06f921c5ab3.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/877d92a3-2117-4530-aa3d-e06f921c5ab3.jpg	2026-02-26 22:11:11.219809
14	1	carlosdiaz.jpg	image/jpeg	68786	/uploads/20a0e503-4bc2-495c-a8e0-390185e08dd2.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/20a0e503-4bc2-495c-a8e0-390185e08dd2.jpg	2026-02-26 22:11:25.407732
15	1	aperfi-logo.jpg	image/jpeg	16214	/uploads/e332e582-3f5b-4195-9d85-1d81b6103c31.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/e332e582-3f5b-4195-9d85-1d81b6103c31.jpg	2026-02-26 22:11:43.438136
16	1	b7kfkpqsbeqmm1e2edn.jpg	image/jpeg	29458	/uploads/daccd096-3235-497b-8ff6-38293b7d5932.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/daccd096-3235-497b-8ff6-38293b7d5932.jpg	2026-02-26 22:11:47.463914
17	1	kof7wlowmckmm1e0qvz.jpg	image/jpeg	32903	/uploads/fc69f8a4-47d7-4862-85fa-bec09093fc83.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/fc69f8a4-47d7-4862-85fa-bec09093fc83.jpg	2026-02-26 22:11:51.211644
18	1	qjbdk3rwsqmm1dz5mj.jpg	image/jpeg	32601	/uploads/d46a1429-1e88-4825-b9a8-66b4ad05c40e.jpg	local	/Users/elsenormanzana/Documents/GitHub/openweb/apps/api/uploads/d46a1429-1e88-4825-b9a8-66b4ad05c40e.jpg	2026-02-26 22:11:57.036226
\.


--
-- Data for Name: newsletter_subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.newsletter_subscribers (id, site_id, email, name, status, source, meta, created_at, updated_at) FROM stdin;
1	1	manzana.carlosdiaz@gmail.com	Carlos Diaz	subscribed	newsletter_block	{}	2026-02-26 23:38:45.877	2026-02-26 23:39:07.287
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, site_id, title, slug, content, is_homepage, ignore_global_layout, seo_title, seo_description, seo_keywords, og_image, no_index, canonical_url, created_at, updated_at, disable_elevated_nav_spacing) FROM stdin;
2	1	Homepage	homepage	[{"id":"d37992bd-d166-4ae7-bbc6-d4ccf9d4ef05","type":"hero","props":{"heading":"AperFi Technologies","subheading":"Software made with High Fidelity","description":"","primaryCta":{"label":"","href":"#"},"secondaryCta":{"label":"","href":"#"},"badgeText":"Under Construction","backgroundType":"image","backgroundColor":"#0f172a","backgroundImage":"/uploads/877d92a3-2117-4530-aa3d-e06f921c5ab3.jpg","backgroundVideo":"","backgroundOpacity":58,"align":"center","textColor":"light"}},{"id":"4127ce6f-3fb9-47ca-a131-17ba6677e091","type":"newsletter","props":{"heading":"Stay in the loop","description":"Get the latest updates, articles and resources delivered to your inbox.","placeholder":"Enter your email","buttonLabel":"Subscribe","backgroundColor":"#2563eb","textColor":"light","align":"center","collectName":true}}]	t	f	\N	\N	\N	\N	f	\N	2026-02-26 21:57:45.816879	2026-02-26 23:53:07.28	t
1	4	Homepage	homepage	[{"id":"ea8aa486-0a18-4638-8d27-02a16f9ae66e","type":"hero","props":{"heading":"AperFi Technologies","subheading":"Software made with High Fidelity","description":"","primaryCta":{"label":"","href":"#"},"secondaryCta":{"label":"","href":"#"},"badgeText":"Under Construction","backgroundType":"color","backgroundColor":"#0f172a","backgroundImage":"","backgroundVideo":"","backgroundOpacity":50,"align":"center","textColor":"light"}},{"id":"7a48bbc0-5acd-4881-9d81-6e40ec23fe44","type":"newsletter","props":{"heading":"Stay in the loop","description":"We are still building this website, join our newsletter to know the latest news.","placeholder":"Enter your email","buttonLabel":"Subscribe","backgroundColor":"#2563eb","textColor":"light","align":"center"}}]	t	f	\N	\N	\N	\N	f	\N	2026-02-26 21:44:58.221616	2026-02-26 21:52:05.657	f
3	1	Contact Us	contact-us	[{"id":"5b361879-b441-4829-aadc-b0557df0ab07","type":"contact","props":{"heading":"Get in touch","subheading":"We'd love to hear from you. Send us a message and we'll respond as soon as possible.","email":"manzana.carlosdiaz@gmail.com","phone":"+1 (787) 908-1584","address":"2010 CARR 64,\\nAPT 465\\nMAYAGUEZ, PR, 00682","showForm":true,"backgroundColor":""}}]	f	f	\N	\N	\N	\N	f	\N	2026-02-26 22:25:28.385334	2026-02-26 22:26:35.24	f
\.


--
-- Data for Name: plugins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugins (id, site_id, name, slug, description, server_code, client_code, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, site_id, nav_type, nav_config, footer_config, seo_config, updated_at, blog_approval_mode) FROM stdin;
1	4	navbar	{"logoText":"Logo","logoHref":"/","navLinks":[{"label":"Home","href":"/"}]}	{"copyright":"© 2025","links":[]}	{"globalSiteName":"AperFi"}	2026-02-26 21:49:36.098	f
2	1	navbar	{"logoText":"AperFi","logoImage":"/uploads/e332e582-3f5b-4195-9d85-1d81b6103c31.jpg","logoHref":"http://localhost:5173/uploads/e332e582-3f5b-4195-9d85-1d81b6103c31.jpg","navLinks":[{"label":"Home","href":"/","dropdown":[]},{"label":"Contact Us","href":"/contact-us","dropdown":[]}],"navVariant":"elevated","headerStyle":"solid","headerBg":"#ffffff","headerTextColor":"#000000","ctaPrimaryText":"","ctaPrimaryHref":"","ctaSecondaryText":"","ctaSecondaryHref":"","heroBadge":"","heroHeadline":"","heroDescription":"","palette":{"primary":"#2563eb","secondary":"#0f172a","accent":"#f59e0b","background":"#ffffff","surface":"#f8fafc","text":"#111827","muted":"#6b7280","border":"#e5e7eb"}}	{"copyright":"© 2025 AperFi Technologies. Software made with High Fidelity","links":[],"columns":[]}	{"globalSiteName":"AperFi","siteSubtitle":"Software made with High Fidelity"}	2026-02-26 22:27:14.216	f
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, name, slug, domain, sub_domain, routing_mode, is_default, created_at) FROM stdin;
1	Default	default	\N	\N	url	t	2026-02-26 17:55:40.893621
\.


--
-- Data for Name: storage_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storage_config (id, provider, config, updated_at, site_id) FROM stdin;
\.


--
-- Data for Name: theme_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.theme_packs (id, name, slug, css_content, created_at, updated_at, site_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, role, site_id, created_at, site_roles, bio, avatar_url, social_media, "position", auth_provider, auth_provider_id) FROM stdin;
1	carlos@aperfi.net	$2b$10$V9Snix.Fec5M9A24NePiiuGv1FeVhxiTMYEYSG4FUM/BhibWeJNfi	admin	\N	2026-02-26 19:28:25.522082	\N	\N	/uploads/20a0e503-4bc2-495c-a8e0-390185e08dd2.jpg	\N	\N	\N	\N
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 9, true);


--
-- Name: blog_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blog_categories_id_seq', 1, false);


--
-- Name: blog_post_authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blog_post_authors_id_seq', 1, false);


--
-- Name: blog_post_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blog_post_categories_id_seq', 1, false);


--
-- Name: blog_post_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blog_post_tags_id_seq', 1, false);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blog_posts_id_seq', 1, false);


--
-- Name: blog_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blog_tags_id_seq', 1, false);


--
-- Name: crm_channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.crm_channels_id_seq', 1, true);


--
-- Name: crm_leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.crm_leads_id_seq', 1, true);


--
-- Name: forms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.forms_id_seq', 1, false);


--
-- Name: media_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.media_items_id_seq', 18, true);


--
-- Name: newsletter_subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.newsletter_subscribers_id_seq', 1, true);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pages_id_seq', 3, true);


--
-- Name: plugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plugins_id_seq', 1, false);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 2, true);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 6, true);


--
-- Name: storage_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.storage_config_id_seq', 1, false);


--
-- Name: theme_packs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.theme_packs_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: blog_categories blog_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_post_authors blog_post_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_authors
    ADD CONSTRAINT blog_post_authors_pkey PRIMARY KEY (id);


--
-- Name: blog_post_categories blog_post_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_categories
    ADD CONSTRAINT blog_post_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_post_tags blog_post_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_tags
    ADD CONSTRAINT blog_post_tags_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_tags blog_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_tags
    ADD CONSTRAINT blog_tags_pkey PRIMARY KEY (id);


--
-- Name: crm_channels crm_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_channels
    ADD CONSTRAINT crm_channels_pkey PRIMARY KEY (id);


--
-- Name: crm_channels crm_channels_site_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_channels
    ADD CONSTRAINT crm_channels_site_slug_unique UNIQUE (site_id, slug);


--
-- Name: crm_leads crm_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_pkey PRIMARY KEY (id);


--
-- Name: forms forms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forms
    ADD CONSTRAINT forms_pkey PRIMARY KEY (id);


--
-- Name: forms forms_site_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forms
    ADD CONSTRAINT forms_site_slug_unique UNIQUE (site_id, slug);


--
-- Name: media_items media_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_items
    ADD CONSTRAINT media_items_pkey PRIMARY KEY (id);


--
-- Name: newsletter_subscribers newsletter_subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_subscribers
    ADD CONSTRAINT newsletter_subscribers_pkey PRIMARY KEY (id);


--
-- Name: newsletter_subscribers newsletter_subscribers_site_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_subscribers
    ADD CONSTRAINT newsletter_subscribers_site_email_unique UNIQUE (site_id, email);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_site_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_site_slug_unique UNIQUE (site_id, slug);


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (id);


--
-- Name: plugins plugins_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_slug_unique UNIQUE (slug);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: sites sites_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_slug_unique UNIQUE (slug);


--
-- Name: storage_config storage_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_config
    ADD CONSTRAINT storage_config_pkey PRIMARY KEY (id);


--
-- Name: theme_packs theme_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.theme_packs
    ADD CONSTRAINT theme_packs_pkey PRIMARY KEY (id);


--
-- Name: theme_packs theme_packs_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.theme_packs
    ADD CONSTRAINT theme_packs_slug_unique UNIQUE (slug);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: blog_categories_site_slug_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blog_categories_site_slug_unique ON public.blog_categories USING btree (site_id, slug);


--
-- Name: blog_post_authors_post_user_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blog_post_authors_post_user_unique ON public.blog_post_authors USING btree (post_id, user_id);


--
-- Name: blog_post_categories_post_category_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blog_post_categories_post_category_unique ON public.blog_post_categories USING btree (post_id, category_id);


--
-- Name: blog_post_tags_post_tag_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blog_post_tags_post_tag_unique ON public.blog_post_tags USING btree (post_id, tag_id);


--
-- Name: blog_posts_site_slug_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blog_posts_site_slug_unique ON public.blog_posts USING btree (site_id, slug);


--
-- Name: blog_tags_site_slug_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blog_tags_site_slug_unique ON public.blog_tags USING btree (site_id, slug);


--
-- Name: users_auth_provider_provider_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_auth_provider_provider_id_unique ON public.users USING btree (auth_provider, auth_provider_id) WHERE ((auth_provider IS NOT NULL) AND (auth_provider_id IS NOT NULL));


--
-- Name: blog_categories blog_categories_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: blog_post_authors blog_post_authors_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_authors
    ADD CONSTRAINT blog_post_authors_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.blog_posts(id) ON DELETE CASCADE;


--
-- Name: blog_post_authors blog_post_authors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_authors
    ADD CONSTRAINT blog_post_authors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: blog_post_categories blog_post_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_categories
    ADD CONSTRAINT blog_post_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.blog_categories(id) ON DELETE CASCADE;


--
-- Name: blog_post_categories blog_post_categories_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_categories
    ADD CONSTRAINT blog_post_categories_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.blog_posts(id) ON DELETE CASCADE;


--
-- Name: blog_post_tags blog_post_tags_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_tags
    ADD CONSTRAINT blog_post_tags_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.blog_posts(id) ON DELETE CASCADE;


--
-- Name: blog_post_tags blog_post_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_post_tags
    ADD CONSTRAINT blog_post_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.blog_tags(id) ON DELETE CASCADE;


--
-- Name: blog_posts blog_posts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: blog_posts blog_posts_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: blog_posts blog_posts_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: blog_tags blog_tags_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_tags
    ADD CONSTRAINT blog_tags_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: crm_channels crm_channels_site_id_sites_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_channels
    ADD CONSTRAINT crm_channels_site_id_sites_id_fk FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: crm_leads crm_leads_channel_id_crm_channels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_channel_id_crm_channels_id_fk FOREIGN KEY (channel_id) REFERENCES public.crm_channels(id) ON DELETE SET NULL;


--
-- Name: crm_leads crm_leads_form_id_forms_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_form_id_forms_id_fk FOREIGN KEY (form_id) REFERENCES public.forms(id) ON DELETE SET NULL;


--
-- Name: crm_leads crm_leads_site_id_sites_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_site_id_sites_id_fk FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: forms forms_site_id_sites_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forms
    ADD CONSTRAINT forms_site_id_sites_id_fk FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: newsletter_subscribers newsletter_subscribers_site_id_sites_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_subscribers
    ADD CONSTRAINT newsletter_subscribers_site_id_sites_id_fk FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: storage_config storage_config_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_config
    ADD CONSTRAINT storage_config_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: theme_packs theme_packs_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.theme_packs
    ADD CONSTRAINT theme_packs_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: users users_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id);


--
-- PostgreSQL database dump complete
--

\unrestrict aByHmUSp6eH7jzXj5afKtI6hu5yNeh06d3gmR93ntnRBADZ3ZfdqKx8ABYVXbCd

