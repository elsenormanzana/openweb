console.log("[Hello World Plugin] client script loaded");
